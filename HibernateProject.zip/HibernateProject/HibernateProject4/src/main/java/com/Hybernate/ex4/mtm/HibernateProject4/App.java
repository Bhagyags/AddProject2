package com.Hybernate.ex4.mtm.HibernateProject4;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {   
        //creating the list for storing employees
        List<Employee> Elist1=new ArrayList<Employee>();
        List<Employee> Elist2=new ArrayList<Employee>();
        List<Employee> Elist3=new ArrayList<Employee>();
        List<Employee> Elist4=new ArrayList<Employee>();
        
        //creating the employee objects
        Employee e1=new Employee();
        Employee e2=new Employee();
        Employee e3=new Employee();
        Employee e4=new Employee();
        Employee e5=new Employee();
        
        //adding the employee objects to list1
        Elist1.add(e1);
        Elist1.add(e5);
        Elist1.add(e3);
        
      //adding the employee objects to list2
        Elist2.add(e1);
        Elist2.add(e2);
        Elist2.add(e4);
        Elist2.add(e5);
        
      //adding the employee objects to list3
        Elist3.add(e2);
        Elist3.add(e4);
        Elist3.add(e5);
        
      //adding the employee objects to list4
        Elist4.add(e1);
        Elist4.add(e2);
        Elist4.add(e3);
        Elist4.add(e4);
        Elist4.add(e5);
        
        //creating the list for storing Technology
        List<Technology> Tlist1=new ArrayList<Technology>();
        List<Technology> Tlist2=new ArrayList<Technology>();
        List<Technology> Tlist3=new ArrayList<Technology>();
        List<Technology> Tlist4=new ArrayList<Technology>();
        List<Technology> Tlist5=new ArrayList<Technology>();
        
        //Creating the objects of technology
        Technology t1=new Technology();
        Technology t2=new Technology();
        Technology t3=new Technology();
        Technology t4=new Technology();
       
        //adding the technology objects to list1
        Tlist1.add(t1);
        Tlist1.add(t2);
        Tlist1.add(t4);
        
      //adding the technology objects to list2
        Tlist2.add(t2);
        Tlist2.add(t3);
        Tlist2.add(t4);
        
      //adding the technology objects to list3
        Tlist3.add(t1);
        Tlist3.add(t4);
        
      //adding the technology objects to list4
        Tlist4.add(t2);
        Tlist4.add(t3);
        Tlist4.add(t4);
        
      //adding the technology objects to list5
        Tlist5.add(t1);
        Tlist5.add(t2);
        Tlist5.add(t3);
        Tlist5.add(t4);
        
        //setting the values for Employee e1 obj
        e1.setE_id(11);
        e1.setE_name("Prakash");
        e1.setE_Team("Team-A");
        e1.setTech(Tlist1);
        
      //setting the values for Employee e2 obj
        e2.setE_id(12);
        e2.setE_name("Praveen");
        e2.setE_Team("Team-B");
        e2.setTech(Tlist2);
        
      //setting the values for Employee e3 obj
        e3.setE_id(13);
        e3.setE_name("Pooja");
        e3.setE_Team("Team-c");
        e3.setTech(Tlist3);
        
      //setting the values for Employee e4 obj
        e4.setE_id(14);
        e4.setE_name("Priya");
        e4.setE_Team("Team-A");
        e4.setTech(Tlist4);
        
      //setting the values for Employee e5 obj
        e5.setE_id(15);
        e5.setE_name("Prateek");
        e5.setE_Team("Team-B");
        e5.setTech(Tlist5);
        
      //setting the values for Technology t1 obj
        t1.setT_id(123);
        t1.setT_name("Java");
        t1.setEmp(Elist1);
        
      //setting the values for Technology t2 obj
        t2.setT_id(124);
        t2.setT_name("MySql");
        t2.setEmp(Elist2);
        
      //setting the values for Technology t3 obj
        t3.setT_id(125);
        t3.setT_name("Python");
        t3.setEmp(Elist3);
        
      //setting the values for Technology t4 obj
        t4.setT_id(126);
        t4.setT_name("React");
        t4.setEmp(Elist4);
        
        Configuration cfg=new Configuration();
        cfg.configure();
        SessionFactory factory=cfg.buildSessionFactory();
        Session session=factory.openSession();
        Transaction trans=session.beginTransaction();
        
        
        session.save(e1);
        session.save(e2);
        session.save(e3);
        session.save(e4);
        session.save(e5);
        
        session.save(t1);
        session.save(t2);
        session.save(t3);
        session.save(t4);
        
        trans.commit();
        System.out.println("Objects are saved");
        
    }
}
