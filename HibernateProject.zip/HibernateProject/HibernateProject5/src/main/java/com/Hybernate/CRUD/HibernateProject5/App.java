package com.Hybernate.CRUD.HibernateProject5;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg=new Configuration();
        cfg.configure();
        SessionFactory factory=cfg.buildSessionFactory();
        Session session=factory.openSession();
        Transaction trans=session.beginTransaction();
              
        //create(session,trans);
        //read(session,trans);
        //update(session,trans);
        delete(session,trans);
        
        
    }

	private static void delete(Session session, Transaction trans) 
	{
		Laptop lp=session.get(Laptop.class,11);
		session.delete(lp);
		trans.commit();
		System.out.println("Data deleted");
	}

	private static void update(Session session, Transaction trans) 
	{
		Laptop lp=session.get(Laptop.class, 11);
		lp.setL_name("Lenovo");
		lp.setL_cost(55000);
		session.update(lp);
		trans.commit();
		System.out.println("Data updated");
		
	}

	public static void read(Session session, Transaction trans) 
	{
		Laptop lap=session.get(Laptop.class, 11);
		trans.commit();
		System.out.println(lap);
	}

	public static void create(Session session, Transaction trans) 
	{
		Laptop l1=new Laptop(11,"Dell",45000);
        Laptop l2=new Laptop(12,"HP",44000);
        Laptop l3=new Laptop(13,"Asus",50000); 
        session.save(l1);
        session.save(l2);
        session.save(l3);
        trans.commit();
        System.out.println("Laptop objects are saved");
	}
}
